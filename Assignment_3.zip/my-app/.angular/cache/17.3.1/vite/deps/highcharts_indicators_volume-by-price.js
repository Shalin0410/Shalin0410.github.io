import {
  __commonJS
} from "./chunk-WKYGNSYM.js";

// node_modules/highcharts/indicators/volume-by-price.js
var require_volume_by_price = __commonJS({
  "node_modules/highcharts/indicators/volume-by-price.js"(exports, module) {
    !/**
    * Highstock JS v11.4.0 (2024-03-04)
    *
    * Indicator series type for Highcharts Stock
    *
    * (c) 2010-2024 Paweł Dalek
    *
    * License: www.highcharts.com/license
    */
    function(e) {
      "object" == typeof module && module.exports ? (e.default = e, module.exports = e) : "function" == typeof define && define.amd ? define("highcharts/indicators/volume-by-price", ["highcharts", "highcharts/modules/stock"], function(t) {
        return e(t), e.Highcharts = t, e;
      }) : e("undefined" != typeof Highcharts ? Highcharts : void 0);
    }(function(e) {
      "use strict";
      var t = e ? e._modules : {};
      function s(e2, t2, s2, i) {
        e2.hasOwnProperty(t2) || (e2[t2] = i.apply(null, s2), "function" == typeof CustomEvent && window.dispatchEvent(new CustomEvent("HighchartsModuleLoaded", { detail: { path: t2, module: e2[t2] } })));
      }
      s(t, "Stock/Indicators/VBP/VBPPoint.js", [t["Core/Series/SeriesRegistry.js"]], function(e2) {
        let { sma: { prototype: { pointClass: t2 } } } = e2.seriesTypes;
        return class extends t2 {
          destroy() {
            this.negativeGraphic && (this.negativeGraphic = this.negativeGraphic.destroy()), super.destroy.apply(this, arguments);
          }
        };
      }), s(t, "Stock/Indicators/VBP/VBPIndicator.js", [t["Stock/Indicators/VBP/VBPPoint.js"], t["Core/Animation/AnimationUtilities.js"], t["Core/Globals.js"], t["Core/Series/SeriesRegistry.js"], t["Core/Utilities.js"]], function(e2, t2, s2, i, o) {
        let { animObject: a } = t2, { noop: n } = s2, { column: { prototype: r }, sma: l } = i.seriesTypes, { addEvent: p, arrayMax: h, arrayMin: d, correctFloat: u, defined: c, error: m, extend: g, isArray: f, merge: v } = o, y = Math.abs;
        class V extends l {
          init(e3, t3) {
            let s3 = this;
            delete t3.data, super.init.apply(s3, arguments);
            let i2 = p(this.chart.constructor, "afterLinkSeries", function() {
              if (s3.options) {
                let t4 = s3.options.params, i3 = s3.linkedParent, o2 = e3.get(t4.volumeSeriesID);
                s3.addCustomEvents(i3, o2);
              }
              i2();
            }, { order: 1 });
            return s3;
          }
          addCustomEvents(e3, t3) {
            let s3 = this, i2 = () => {
              s3.chart.redraw(), s3.setData([]), s3.zoneStarts = [], s3.zoneLinesSVG && (s3.zoneLinesSVG = s3.zoneLinesSVG.destroy());
            };
            return s3.dataEventsToUnbind.push(p(e3, "remove", function() {
              i2();
            })), t3 && s3.dataEventsToUnbind.push(p(t3, "remove", function() {
              i2();
            })), s3;
          }
          animate(e3) {
            let t3 = this, s3 = t3.chart.inverted, i2 = t3.group, o2 = {};
            if (!e3 && i2) {
              let e4 = s3 ? t3.yAxis.top : t3.xAxis.left;
              s3 ? (i2["forceAnimate:translateY"] = true, o2.translateY = e4) : (i2["forceAnimate:translateX"] = true, o2.translateX = e4), i2.animate(o2, g(a(t3.options.animation), { step: function(e5, s4) {
                t3.group.attr({ scaleX: Math.max(1e-3, s4.pos) });
              } }));
            }
          }
          drawPoints() {
            this.options.volumeDivision.enabled && (this.posNegVolume(true, true), r.drawPoints.apply(this, arguments), this.posNegVolume(false, false)), r.drawPoints.apply(this, arguments);
          }
          posNegVolume(e3, t3) {
            let s3 = t3 ? ["positive", "negative"] : ["negative", "positive"], i2 = this.options.volumeDivision, o2 = this.points.length, a2 = [], n2 = [], r2 = 0, l2, p2, h2, d2;
            for (e3 ? (this.posWidths = a2, this.negWidths = n2) : (a2 = this.posWidths, n2 = this.negWidths); r2 < o2; r2++)
              (d2 = this.points[r2])[s3[0] + "Graphic"] = d2.graphic, d2.graphic = d2[s3[1] + "Graphic"], e3 && (l2 = d2.shapeArgs.width, (h2 = (p2 = this.priceZones[r2]).wholeVolumeData) ? (a2.push(l2 / h2 * p2.positiveVolumeData), n2.push(l2 / h2 * p2.negativeVolumeData)) : (a2.push(0), n2.push(0))), d2.color = t3 ? i2.styles.positiveColor : i2.styles.negativeColor, d2.shapeArgs.width = t3 ? this.posWidths[r2] : this.negWidths[r2], d2.shapeArgs.x = t3 ? d2.shapeArgs.x : this.posWidths[r2];
          }
          translate() {
            let e3 = this, t3 = e3.options, s3 = e3.chart, i2 = e3.yAxis, o2 = i2.min, a2 = e3.options.zoneLines, n2 = e3.priceZones, l2 = 0, p2, d2, c2, m2, g2, f2, v2, V2, x, D;
            r.translate.apply(e3);
            let S = e3.points;
            S.length && (v2 = t3.pointPadding < 0.5 ? t3.pointPadding : 0.1, p2 = h(e3.volumeDataArray), d2 = s3.plotWidth / 2, V2 = s3.plotTop, c2 = y(i2.toPixels(o2) - i2.toPixels(o2 + e3.rangeStep)), g2 = y(i2.toPixels(o2) - i2.toPixels(o2 + e3.rangeStep)), v2 && (m2 = y(c2 * (1 - 2 * v2)), l2 = y((c2 - m2) / 2), c2 = y(m2)), S.forEach(function(t4, s4) {
              x = t4.barX = t4.plotX = 0, D = t4.plotY = i2.toPixels(n2[s4].start) - V2 - (i2.reversed ? c2 - g2 : c2) - l2, f2 = u(d2 * n2[s4].wholeVolumeData / p2), t4.pointWidth = f2, t4.shapeArgs = e3.crispCol.apply(e3, [x, D, f2, c2]), t4.volumeNeg = n2[s4].negativeVolumeData, t4.volumePos = n2[s4].positiveVolumeData, t4.volumeAll = n2[s4].wholeVolumeData;
            }), a2.enabled && e3.drawZones(s3, i2, e3.zoneStarts, a2.styles));
          }
          getExtremes() {
            let e3;
            let t3 = this.options.compare, s3 = this.options.cumulative;
            return this.options.compare ? (this.options.compare = void 0, e3 = super.getExtremes(), this.options.compare = t3) : this.options.cumulative ? (this.options.cumulative = false, e3 = super.getExtremes(), this.options.cumulative = s3) : e3 = super.getExtremes(), e3;
          }
          getValues(e3, t3) {
            let s3 = e3.processedXData, i2 = e3.processedYData, o2 = this.chart, a2 = t3.ranges, n2 = [], r2 = [], l2 = [], p2 = o2.get(t3.volumeSeriesID);
            if (!e3.chart) {
              m("Base series not found! In case it has been removed, add a new one.", true, o2);
              return;
            }
            if (!p2 || !p2.processedXData.length) {
              let e4 = p2 && !p2.processedXData.length ? " does not contain any data." : " not found! Check `volumeSeriesID`.";
              m("Series " + t3.volumeSeriesID + e4, true, o2);
              return;
            }
            let h2 = f(i2[0]);
            if (h2 && 4 !== i2[0].length) {
              m("Type of " + e3.name + " series is different than line, OHLC or candlestick.", true, o2);
              return;
            }
            return (this.priceZones = this.specifyZones(h2, s3, i2, a2, p2)).forEach(function(e4, t4) {
              n2.push([e4.x, e4.end]), r2.push(n2[t4][0]), l2.push(n2[t4][1]);
            }), { values: n2, xData: r2, yData: l2 };
          }
          specifyZones(e3, t3, s3, i2, o2) {
            let a2 = !!e3 && function(e4) {
              let t4 = e4.length, s4 = e4[0][3], i3 = s4, o3 = 1, a3;
              for (; o3 < t4; o3++)
                (a3 = e4[o3][3]) < s4 && (s4 = a3), a3 > i3 && (i3 = a3);
              return { min: s4, max: i3 };
            }(s3), n2 = this.zoneStarts = [], r2 = [], l2 = a2 ? a2.min : d(s3), p2 = a2 ? a2.max : h(s3), m2 = 0, g2 = 1, f2 = this.linkedParent;
            if (!this.options.compareToMain && f2.dataModify && (l2 = f2.dataModify.modifyValue(l2), p2 = f2.dataModify.modifyValue(p2)), !c(l2) || !c(p2))
              return this.points.length && (this.setData([]), this.zoneStarts = [], this.zoneLinesSVG && (this.zoneLinesSVG = this.zoneLinesSVG.destroy())), [];
            let v2 = this.rangeStep = u(p2 - l2) / i2;
            for (n2.push(l2); m2 < i2 - 1; m2++)
              n2.push(u(n2[m2] + v2));
            n2.push(p2);
            let y2 = n2.length;
            for (; g2 < y2; g2++)
              r2.push({ index: g2 - 1, x: t3[0], start: n2[g2 - 1], end: n2[g2] });
            return this.volumePerZone(e3, r2, o2, t3, s3);
          }
          volumePerZone(e3, t3, s3, i2, o2) {
            let a2, n2, r2, l2, p2;
            let h2 = this, d2 = s3.processedXData, u2 = s3.processedYData, c2 = t3.length - 1, m2 = o2.length, g2 = u2.length;
            return y(m2 - g2) && (i2[0] !== d2[0] && u2.unshift(0), i2[m2 - 1] !== d2[g2 - 1] && u2.push(0)), h2.volumeDataArray = [], t3.forEach(function(t4) {
              for (p2 = 0, t4.wholeVolumeData = 0, t4.positiveVolumeData = 0, t4.negativeVolumeData = 0; p2 < m2; p2++) {
                n2 = false, r2 = false, l2 = e3 ? o2[p2][3] : o2[p2], a2 = p2 ? e3 ? o2[p2 - 1][3] : o2[p2 - 1] : l2;
                let s4 = h2.linkedParent;
                !h2.options.compareToMain && s4.dataModify && (l2 = s4.dataModify.modifyValue(l2), a2 = s4.dataModify.modifyValue(a2)), l2 <= t4.start && 0 === t4.index && (n2 = true), l2 >= t4.end && t4.index === c2 && (r2 = true), (l2 > t4.start || n2) && (l2 < t4.end || r2) && (t4.wholeVolumeData += u2[p2], a2 > l2 ? t4.negativeVolumeData += u2[p2] : t4.positiveVolumeData += u2[p2]);
              }
              h2.volumeDataArray.push(t4.wholeVolumeData);
            }), t3;
          }
          drawZones(e3, t3, s3, i2) {
            let o2 = e3.renderer, a2 = e3.plotWidth, n2 = e3.plotTop, r2 = this.zoneLinesSVG, l2 = [], p2;
            s3.forEach(function(s4) {
              p2 = t3.toPixels(s4) - n2, l2 = l2.concat(e3.renderer.crispLine([["M", 0, p2], ["L", a2, p2]], i2.lineWidth));
            }), r2 ? r2.animate({ d: l2 }) : r2 = this.zoneLinesSVG = o2.path(l2).attr({ "stroke-width": i2.lineWidth, stroke: i2.color, dashstyle: i2.dashStyle, zIndex: this.group.zIndex + 0.1 }).add(this.group);
          }
        }
        return V.defaultOptions = v(l.defaultOptions, { params: { index: void 0, period: void 0, ranges: 12, volumeSeriesID: "volume" }, zoneLines: { enabled: true, styles: { color: "#0A9AC9", dashStyle: "LongDash", lineWidth: 1 } }, volumeDivision: { enabled: true, styles: { positiveColor: "rgba(144, 237, 125, 0.8)", negativeColor: "rgba(244, 91, 91, 0.8)" } }, animationLimit: 1e3, enableMouseTracking: false, pointPadding: 0, zIndex: -1, crisp: true, dataGrouping: { enabled: false }, dataLabels: { allowOverlap: true, enabled: true, format: "P: {point.volumePos:.2f} | N: {point.volumeNeg:.2f}", padding: 0, style: { fontSize: "0.5em" }, verticalAlign: "top" } }), g(V.prototype, { nameBase: "Volume by Price", nameComponents: ["ranges"], calculateOn: { chart: "render", xAxis: "afterSetExtremes" }, pointClass: e2, markerAttribs: n, drawGraph: n, getColumnMetrics: r.getColumnMetrics, crispCol: r.crispCol }), i.registerSeriesType("vbp", V), V;
      }), s(t, "masters/indicators/volume-by-price.src.js", [t["Core/Globals.js"]], function(e2) {
        return e2;
      });
    });
  }
});
export default require_volume_by_price();
//# sourceMappingURL=highcharts_indicators_volume-by-price.js.map
